package EX2;

public interface Pagamento {
	void processarPagamento();
}
