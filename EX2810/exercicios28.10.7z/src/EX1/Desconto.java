package EX1;


public interface Desconto {
	
	 double calcularDesconto(Produto produto);
}

